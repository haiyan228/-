import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.Arrays;

//封装类
class core{

    //单独运行yq.exe或者yq.java，给出全省输入文件的输出；
    public void getAllProvince() throws Exception {
        FileReader file = new FileReader("E:\\testData\\yq_in.txt");
        BufferedReader br = new BufferedReader(file);
        FileOutputStream fos = new FileOutputStream("E:\\testData\\yq_out.txt");

        String line = br.readLine();
        String shen = "";
        int count = 1;

        while(line != null) {

            String[] word = line.split("\t");
            String data = "";

            if(!shen.equals(word[0]) && !word[2].equals("0")) {
                if(count == 1) {
                    data = word[0] + "\n" + word[1] + "\t" + word[2] + "\n";
                    fos.write(data.getBytes());
                    count++;
                }else {
                    data = "\n" +word[0] + "\n" + word[1] + "\t" + word[2] + "\n";
                    fos.write(data.getBytes());
                }
                shen = word[0];
            }else if(shen.equals(word[0]) && !word[2].equals("0")) {
                data = word[1] + "\t" + word[2] + "\n";
                fos.write(data.getBytes());
            }
            line = br.readLine();
        }
        br.close();
        file.close();
        fos.close();
    }

    //运行yq [指定输入文件] [指定输出文件]；（按要求排序）
    public void getOneProvince(String inpath, String outpath, String shen) throws Exception {
        FileReader file = new FileReader(inpath);
        BufferedReader br = new BufferedReader(file);
        FileOutputStream fos = new FileOutputStream(outpath);

        String line = br.readLine();

        String data = shen + "\n";
        fos.write(data.getBytes());

        String[] city = new String[1000];
        while (line != null) {
            String[] word = line.split("\t");
            if (word[0].equals(shen) && !word[2].equals("0")) {
                int con = Integer.parseInt(word[2]);
                if (city[con] == null)
                    city[con] = word[1];
                else
                    city[con] = city[con] + "," + word[1];
            }
            line = br.readLine();
        }
        for (int i = 999; i >= 0; i--) {
            if (city[i] != null) {
                String[] split = city[i].split(",");
                if (split.length == 1) {
                    data = city[i] + "\t" + i + "\n";
                    fos.write(data.getBytes());
                } else {
                    Arrays.sort(split);
                    for (String string : split) {
                        data = string + "\t" + i + "\n";
                        fos.write(data.getBytes());
                    }
                }
            }
        }
        br.close();
        file.close();
        fos.close();
    }


    //3.运行yq [指定输入文件] [指定省份]；（按要求排序）
    public void getAllProvinceToFile(String inpath, String outpath) throws Exception {
        FileReader file = new FileReader(inpath);
        BufferedReader br = new BufferedReader(file);
        FileOutputStream fos = new FileOutputStream(outpath);

        String line = br.readLine();
        String shen = line.split("\n")[0];
        int sum = 0;
        String[] shenfen = new String[3000];

        while(line != null) {
            String[] word = line.split("\t");
            if(word[0].equals(shen)) {
                sum += Integer.parseInt(word[2]);
            }else {
                shenfen[sum] = shen;
                sum = 0;
                shen = word[0];
            }
            line = br.readLine();
        }
        br.close();
        shenfen[sum] = shen;
        for(int i = 2999; i > 0; i--) {
            if(shenfen[i] != null) {
                write_for_count(shenfen[i],inpath,fos);
            }
        }
        file.close();
        br.close();
        fos.close();
    }

    //指定输入省份按排序输出
    private void write_for_count(String shen, String inpath, FileOutputStream fos) throws Exception {
        FileReader file = new FileReader(inpath);
        BufferedReader br = new BufferedReader(file);
        String line = br.readLine();

        String data = "\n"+shen+"\n";
        fos.write(data.getBytes());

        String[] city = new String[1000];
        while (line != null) {
            String[] word = line.split("\t");
            if (word[0].equals(shen) && !word[2].equals("0")) {
                int con = Integer.parseInt(word[2]);
                if (city[con] == null)
                    city[con] = word[1];
                else
                    city[con] = city[con] + "," + word[1];
            }
            line = br.readLine();
        }

        for (int i = 999; i > 0; i--) {
            if (city[i] != null) {
                String[] split = city[i].split(",");
                if (split.length == 1) {
                    data = city[i] + "\t" + i + "\n";
                    fos.write(data.getBytes());
                } else {
                    Arrays.sort(split);
                    for (String string : split) {
                        data = string + "\t" + i + "\n";
                        fos.write(data.getBytes());
                    }
                }
            }
        }
        br.close();
        file.close();
    }



}
