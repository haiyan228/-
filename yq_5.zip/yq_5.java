public class yq_5 {
    //main方法测试
    public static void main(String[] args) throws Exception {
        core c = new core();
        if(args.length == 0) c.getAllProvince();
        else if(args.length == 2) c.getAllProvinceToFile(args[0], args[1]);
        else if(args.length == 3) c.getOneProvince(args[0], args[1], args[2]);
    }
}

